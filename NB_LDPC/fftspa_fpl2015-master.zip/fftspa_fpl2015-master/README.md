# fftspa_fpl2015

In this project you can find the source code referring to the FFT-SPA Non-binary LDPC decoder for Vivado HLS published in FPL 2015 paper "From Low-architectural Expertise Up to High-throughput Non-binary LDPC Decoders: Optimization Guidelines using High-level Synthesis", Joao Andrade*, Nithin George^, Kimon Karras+, David Novo^, Vitor Silva*, Paolo Ienne^ and Gabriel Falcao*.

* (*) Instituto de Telecomunicações, Dept. Electrical and Computer Engineering, University of Coimbra, Portugal
http://www.it.pt/?msp-co

* (^)École Polytechnique Fédérale de Lausanne, School of Computer and Communication Sciences, Lausanne, Switzerland
http://www.lap.epfl.ch

+ (+)Xilinx Research Labs, Dublin, Ireland 
