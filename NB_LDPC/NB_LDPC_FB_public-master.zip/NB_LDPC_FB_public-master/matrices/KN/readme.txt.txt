Matrice from Kaiserslautern

http://www.uni-kl.de/channel-codes/channel-codes-database/non-binary-ldpc/