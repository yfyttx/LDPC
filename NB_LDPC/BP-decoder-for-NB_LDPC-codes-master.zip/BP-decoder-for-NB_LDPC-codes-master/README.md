# BP-decoder-for-NB_LDPC-codes
Platform which do NB-LDPC sum-product decoder (flooding and layered) using (MacKay and Davey) FFT-QSPA (2,3 value in first parameter) and Majority decoding (3,4). Use of FFT allow to use with different prime size up to 1024. 
